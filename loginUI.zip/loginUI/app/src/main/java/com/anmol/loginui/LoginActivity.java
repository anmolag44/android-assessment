package com.anmol.loginui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

        EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView btn = findViewById(R.id.signupbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    public void toMain(View view) {
        username= (EditText) findViewById(R.id.input_email);
        password= (EditText) findViewById(R.id.login_password);
        String inputUsername = username.getText().toString();
        String inputPassword = password.getText().toString();
        if(inputUsername.equalsIgnoreCase("Harman") && inputPassword.equalsIgnoreCase("Harman")){
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Welcome ", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, " Enter Correct Username and Password \n (id = Harman & pass = Harman)", Toast.LENGTH_LONG).show();
        }


    }
    public void forgotpass(View view) {
        Toast.makeText(this, "Try to remember the password Huhh \n Eat 10 Almonds everyday ", Toast.LENGTH_LONG).show();
    }

}