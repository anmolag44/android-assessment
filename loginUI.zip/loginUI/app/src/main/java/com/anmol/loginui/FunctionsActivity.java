package com.anmol.loginui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Telephony;
import android.view.View;

public class FunctionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_functions);
    }


    public void openBrowser(View view)
    {
        String url= "http://www.google.com";
        Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    public void makeCall(View view)
    {
        Intent intent=new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"));
        startActivity(intent);
    }

    public void sendSms(View view)
    {
        Intent intent = getPackageManager().getLaunchIntentForPackage(Telephony.Sms.getDefaultSmsPackage(this));
        if(intent != null)
        {
            startActivity(intent);
        }
    }

    public void sendEmail(View view)
    {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
        if(intent != null)
        {
            startActivity(intent);
        }
    }

    public void toMain(View view) {
        Intent intent = new Intent(FunctionsActivity.this, MainActivity.class);
        startActivity(intent);
    }


}