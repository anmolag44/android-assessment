package com.anmol.loginui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    View view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater m = getMenuInflater();
        m.inflate(R.menu.options,menu);
        return true;
    }

    public void Signout(View view) {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Welcome ", Toast.LENGTH_LONG).show();
    }

    public void toProfile(View view) {
        Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
        startActivity(intent);

    }

    public void toSettings(View view) {
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
        startActivity(intent);

    }

    public void toFunctions(View view) {
        Intent intent = new Intent(MainActivity.this, FunctionsActivity.class);
        startActivity(intent);

    }

    public void toDoList(View view) {
        Intent intent = new Intent(MainActivity.this, ToDoList.class);
        startActivity(intent);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.i1:
                toProfile(view);
                break;
            case R.id.i2:
                toSettings(view);
                break;
            case R.id.i3:
                Signout(view);
                break;
            case R.id.i4:
                toFunctions(view);
                break;
            case R.id.i5:
                toDoList(view);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}